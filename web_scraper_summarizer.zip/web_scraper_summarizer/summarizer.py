import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from collections import Counter

# Download required NLTK datasets
nltk.download('punkt')
nltk.download('stopwords')

def summarize_content(content, num_sentences=3):
    """Summarizes content by extracting important sentences."""
    sentences = sent_tokenize(content)
    words = word_tokenize(content.lower())
    stop_words = set(stopwords.words('english'))
    
    # Count word frequencies excluding stopwords
    word_frequencies = Counter(word for word in words if word not in stop_words and word.isalnum())
    
    # Rank sentences by the sum of word frequencies
    sentence_scores = {}
    for sentence in sentences:
        for word in word_tokenize(sentence.lower()):
            if word in word_frequencies:
                sentence_scores[sentence] = sentence_scores.get(sentence, 0) + word_frequencies[word]
    
    # Select top N sentences
    top_sentences = sorted(sentence_scores, key=sentence_scores.get, reverse=True)[:num_sentences]
    return " ".join(top_sentences)
