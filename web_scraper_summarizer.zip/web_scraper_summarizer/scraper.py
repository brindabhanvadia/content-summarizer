import requests
from bs4 import BeautifulSoup

def fetch_webpage(url):
    """Fetches the HTML content of the webpage."""
    try:
        response = requests.get(url)
        response.raise_for_status()
        return response.text
    except requests.exceptions.RequestException as e:
        print(f"Error fetching the webpage: {e}")
        return None

def extract_content(html_content, tag='p'):
    """Extracts textual content from the given HTML."""
    soup = BeautifulSoup(html_content, 'html.parser')
    paragraphs = soup.find_all(tag)
    content = " ".join([para.get_text(strip=True) for para in paragraphs])
    return content
