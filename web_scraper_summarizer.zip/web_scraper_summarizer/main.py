from scraper import fetch_webpage, extract_content
from summarizer import summarize_content

def main():
    # Step 1: Input the URL
    url = input("Enter the URL of the webpage to summarize: ")
    
    # Step 2: Fetch webpage content
    html_content = fetch_webpage(url)
    if not html_content:
        return
    
    # Step 3: Extract textual content
    extracted_content = extract_content(html_content)
    if not extracted_content.strip():
        print("No textual content found on the page.")
        return
    
    print("\nExtracted Content:\n", extracted_content[:500], "...\n")  # Preview
    
    # Step 4: Summarize content
    summary = summarize_content(extracted_content)
    print("\nSummary:\n", summary)

if __name__ == "__main__":
    main()
